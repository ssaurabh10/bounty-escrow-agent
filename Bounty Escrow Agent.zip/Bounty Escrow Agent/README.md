# Bounty Escrow Agent — AlgoKit LocalNet Edition

**Team Marcos.dev | BIT Sindri | Hackatron 3.0**

> Decentralized bounty escrow with automated oracle arbitration, running on AlgoKit LocalNet.

---

## Quick Start

Run everything from the **repository root** so paths and `.algokit.toml` match what AlgoKit expects.

```bash
# 1. Start LocalNet (requires Docker Desktop)
algokit localnet start

# 2. Build smart contract artifacts (TEAL + ABI under smart_contracts/bounty_escrow/artifacts)
python smart_contracts/bounty_escrow/contract.py

# 3. Deploy to LocalNet (uses [project.deploy] in .algokit.toml)
algokit project deploy localnet

# In CI or scripts, use non-interactive mode:
# algokit project deploy localnet --non-interactive

# 4. Run E2E tests (needs LocalNet + deploy)
python tests/test_bounty_escrow.py

# 5. Demo UI (localStorage + optional Pera for identity)
start frontend/index.html

# On-chain UI (KMD / Pera signing — serve repo root so ABI loads)
# npx serve .
# Open http://localhost:3000/frontend/chain-desk.html (port may vary)
```

**Offline contract checks (no chain):** after `pip install -r requirements-dev.txt`, run `python -m pytest tests/test_contract_unit.py -q`. These validate TEAL build, ABI shape, and status constants—useful before E2E.

**Direct deploy without AlgoKit:** `python smart_contracts/bounty_escrow/deploy_config.py` runs the same script; prefer `algokit project deploy localnet` so demos and automation share one entry point.

On Windows, if `algokit project deploy localnet` fails with a Unicode/console error, use `PYTHONUTF8=1` (PowerShell: `$env:PYTHONUTF8='1'`) before the Python deploy script, or run the full stack script below.

### Full local stack (chain + funding API + Judge0 + UI)

One command starts **LocalNet**, **builds and deploys** the contract (including **funding the app account**), then runs:

| Service | Port | Role |
|--------|------|------|
| Judge0 proxy | 3456 | Code execution from the browser (`node oracle/judge0_proxy.js`) |
| Wallet / faucet API | 3457 | List KMD accounts and fund addresses (`python oracle/localnet_wallet_api.py`) |
| Static site | 3000 | `npx serve .` — open `/frontend/index.html` |

From the project directory:

```powershell
.\deploy-full-local.ps1
```

Optional: `-SkipLocalnet` if LocalNet is already running; `-WithOracle` to also start `oracle_runner.py --poll <app_id>`; `-NoServe` if you only want chain + proxies.

Stop the background helpers:

```powershell
.\stop-full-local.ps1
```

Double-click: `deploy-full-local.cmd`

---

## Project Structure

```
Bounty Escrow Agent/
├── smart_contracts/
│   └── bounty_escrow/
│       ├── contract.py          # Beaker/PyTeal smart contract
│       ├── deploy_config.py     # LocalNet deployment (KMD accounts)
│       ├── artifacts/           # Generated TEAL + ABI JSON
│       └── deploy_info.json     # Output: app_id, addresses
├── oracle/
│   └── oracle_runner.py         # Piston API oracle (poll + manual modes)
├── frontend/
│   ├── index.html               # Demo UI (localStorage; Pera optional for login)
│   ├── chain-desk.html          # On-chain ops (KMD LocalNet + Pera TestNet)
│   └── src/
│       ├── algoClient.js        # AlgoSDK + KMD wallet client
│       ├── ipfsUtils.js         # Mock IPFS (localStorage)
│       └── creditScore.js       # CIBIL-inspired scoring
├── tests/
│   ├── conftest.py              # Pytest path setup
│   ├── test_contract_unit.py    # Offline: build / ABI / schema (pytest)
│   └── test_bounty_escrow.py    # E2E on LocalNet (5 scenarios)
├── .algokit.toml                # AlgoKit project config
├── .env.localnet                # LocalNet endpoints
├── deploy-full-local.ps1        # LocalNet + deploy + Judge0 + wallet API + serve
├── deploy-full-local.cmd        # Launcher for the above (Windows)
├── stop-full-local.ps1          # Stop helpers started by deploy-full-local.ps1
├── requirements-dev.txt         # pytest (optional, for unit tests)
└── README.md
```

---

## Status Machine

```
OPEN → ACCEPTED → SUBMITTED → APPROVED  ✅ (creator approves)
                            ↘ REJECTED  ❌ (creator rejects)
                                  ↓
                    ┌─────────────┴──────────────┐
                    ↓                            ↓
               DISPUTED ⚖️                  OPTED_OUT 🚪
               (dispute raised)           (contributor walks)
                    ↓
         ┌──────────┴──────────┐
         ↓                     ↓
  RESOLVED_WORKER 🏆    RESOLVED_CREATOR
  (contributor wins)    (creator wins)

Also: SUBMITTED ──5 min silence──→ AUTO_RELEASE → APPROVED
```

**Note:** Timers are 5 minutes on LocalNet (5 days in production).

---

## Oracle Usage

```bash
# Auto-poll mode (watches contract, auto-resolves disputes)
python oracle/oracle_runner.py --poll <app_id>

# Manual verdict submission
python oracle/oracle_runner.py --verdict <app_id> PASS
python oracle/oracle_runner.py --verdict <app_id> FAIL

# Evaluate code files
python oracle/oracle_runner.py solution.py tests.py <frozen_hash>
```

---

## LocalNet Accounts

| Role        | Source        | Purpose                     |
|-------------|---------------|-----------------------------|
| Creator     | KMD Account 0 | Posts + funds bounties       |
| Worker      | KMD Account 1 | Accepts + submits work       |
| Arbitrator  | KMD Account 2 | Human verdicts + oracle      |

All accounts are pre-funded with ALGO on LocalNet.

---

## Key Differences from Production

| Feature          | LocalNet              | Production (TestNet)     |
|------------------|-----------------------|--------------------------|
| Timer duration   | 5 minutes             | 5 days                   |
| Wallet           | KMD (auto-sign)       | Pera Wallet (user signs) |
| IPFS             | localStorage mock     | Infura/Pinata IPFS       |
| Oracle auth      | Any account can call  | Designated oracle only   |
| Transaction conf | Instant (~4s)         | ~4.5 seconds             |

---

## Credit Score Formula

```
raw   = completions*100 + disputes_won*50 - disputes_lost*80 - opted_out*30
score = clamp(300 + (raw / max_expected) * 600, 300, 900)
```

| Tier     | Range   | Access Level              |
|----------|---------|---------------------------|
| Unranked | 300–449 | Basic bounties only       |
| Bronze   | 450–599 | Standard bounties         |
| Silver   | 600–699 | Mid-tier bounties         |
| Gold     | 700–799 | All bounties + priority   |
| Platinum | 800–900 | Premium bounties + mentor |
