"""
LocalNet Wallet API — Bounty Escrow Agent
========================================
Small local HTTP API to:
- list AlgoKit LocalNet KMD accounts
- fund an address from account[0] (faucet-style)

Run:
  python oracle/localnet_wallet_api.py

Endpoints:
  GET  /health
  GET  /accounts
  POST /fund   {"address": "...", "microalgos": 1000000}

Notes:
- Intended for local development only.
- Requires AlgoKit LocalNet running (algod on :4001, kmd on :4002).
"""

from __future__ import annotations

import json
import sys
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any

from algosdk import encoding, kmd
from algosdk.transaction import PaymentTxn, wait_for_confirmation
from algosdk.v2client import algod


ALGOD_ADDRESS = "http://localhost:4001"
ALGOD_TOKEN = "a" * 64
KMD_ADDRESS = "http://localhost:4002"
KMD_TOKEN = "a" * 64

HOST = "127.0.0.1"
PORT = 3457


if sys.platform == "win32":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")


def _json(obj: Any) -> bytes:
    return json.dumps(obj, indent=2).encode("utf-8")


def get_kmd_accounts() -> list[dict[str, str]]:
    kmd_client = kmd.KMDClient(KMD_TOKEN, KMD_ADDRESS)
    wallets = kmd_client.list_wallets()
    default_wallet = next((w for w in wallets if w["name"] == "unencrypted-default-wallet"), None)
    if not default_wallet:
        raise RuntimeError("LocalNet default KMD wallet not found. Is LocalNet running?")

    handle = kmd_client.init_wallet_handle(default_wallet["id"], "")
    try:
        addrs = kmd_client.list_keys(handle)
        accounts: list[dict[str, str]] = []
        for a in addrs:
            accounts.append({"address": a})
        return accounts
    finally:
        kmd_client.release_wallet_handle(handle)


def export_private_key_for_address(address: str) -> bytes:
    kmd_client = kmd.KMDClient(KMD_TOKEN, KMD_ADDRESS)
    wallets = kmd_client.list_wallets()
    default_wallet = next((w for w in wallets if w["name"] == "unencrypted-default-wallet"), None)
    if not default_wallet:
        raise RuntimeError("LocalNet default KMD wallet not found. Is LocalNet running?")

    handle = kmd_client.init_wallet_handle(default_wallet["id"], "")
    try:
        return kmd_client.export_key(handle, "", address)
    finally:
        kmd_client.release_wallet_handle(handle)


def fund_address(receiver: str, microalgos: int) -> dict[str, Any]:
    if not encoding.is_valid_address(receiver):
        raise ValueError("Invalid Algorand address")
    if microalgos <= 0:
        raise ValueError("microalgos must be > 0")

    algod_client = algod.AlgodClient(ALGOD_TOKEN, ALGOD_ADDRESS)

    # Use account[0] as faucet
    accounts = get_kmd_accounts()
    if not accounts:
        raise RuntimeError("No KMD accounts available")
    faucet_addr = accounts[0]["address"]
    faucet_pk = export_private_key_for_address(faucet_addr)

    params = algod_client.suggested_params()
    txn = PaymentTxn(sender=faucet_addr, sp=params, receiver=receiver, amt=int(microalgos))
    stxn = txn.sign(faucet_pk)
    txid = algod_client.send_transaction(stxn)
    wait_for_confirmation(algod_client, txid, 4)

    bal = algod_client.account_info(receiver)["amount"]
    return {"txid": txid, "receiver": receiver, "microalgos": microalgos, "receiver_balance": bal}


class Handler(BaseHTTPRequestHandler):
    def _cors(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")

    def do_OPTIONS(self):
        self.send_response(204)
        self._cors()
        self.end_headers()

    def do_GET(self):
        try:
            if self.path == "/health":
                self.send_response(200)
                self._cors()
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(_json({"status": "ok", "service": "localnet_wallet_api", "port": PORT}))
                return

            if self.path == "/accounts":
                accounts = get_kmd_accounts()
                self.send_response(200)
                self._cors()
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(_json({"accounts": accounts}))
                return

            self.send_response(404)
            self._cors()
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(_json({"error": "Not found"}))
        except Exception as e:
            self.send_response(500)
            self._cors()
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(_json({"error": str(e)}))

    def do_POST(self):
        try:
            if self.path != "/fund":
                self.send_response(404)
                self._cors()
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(_json({"error": "Not found"}))
                return

            length = int(self.headers.get("Content-Length", "0"))
            raw = self.rfile.read(length).decode("utf-8", errors="replace")
            payload = json.loads(raw or "{}")

            receiver = str(payload.get("address", "")).strip()
            microalgos = int(payload.get("microalgos", 0))
            result = fund_address(receiver, microalgos)

            self.send_response(200)
            self._cors()
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(_json(result))
        except Exception as e:
            self.send_response(500)
            self._cors()
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(_json({"error": str(e)}))


def main() -> None:
    print(f"[LocalNetWalletAPI] Listening on http://{HOST}:{PORT}")
    server = ThreadingHTTPServer((HOST, PORT), Handler)
    server.serve_forever()


if __name__ == "__main__":
    main()

