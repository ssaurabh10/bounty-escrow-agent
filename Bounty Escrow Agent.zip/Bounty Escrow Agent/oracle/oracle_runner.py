"""
Oracle / CI Runner — Bounty Escrow Agent (LocalNet Edition)
Watches contract state, runs tests via Piston API, submits verdict.

Modes:
  1. Manual:  python oracle_runner.py <code_file> <test_file> <frozen_hash>
  2. Poll:    python oracle_runner.py --poll <app_id>
  3. Verdict: python oracle_runner.py --verdict <app_id> <PASS|FAIL>

Prerequisites:
  - AlgoKit LocalNet running
  - Contract deployed (algokit project deploy localnet → deploy_info.json)
"""

import hashlib
import json
import sys
import time

# Keep stdout/stderr UTF-8 on Windows so emoji logs don't crash.
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

import requests
from algosdk.v2client import algod
from algosdk import encoding, kmd
from algosdk.atomic_transaction_composer import (
    AtomicTransactionComposer,
    AccountTransactionSigner,
)
from pathlib import Path

PROJECT_DIR = Path(__file__).resolve().parent.parent
if str(PROJECT_DIR) not in sys.path:
    sys.path.insert(0, str(PROJECT_DIR))

from smart_contracts.bounty_escrow.abi_helpers import (
    decode_app_state,
    load_contract,
    score_box_ref,
)


# ── Config ────────────────────────────────────────────────────────────────────

ALGOD_ADDRESS = "http://localhost:4001"
ALGOD_TOKEN   = "a" * 64
KMD_ADDRESS   = "http://localhost:4002"
KMD_TOKEN     = "a" * 64

PISTON_API_URL = "https://emkc.org/api/v2/piston"

POLL_INTERVAL = 5  # seconds between polls


# ── Hash Utilities ────────────────────────────────────────────────────────────

def sha256_file(path: str) -> str:
    """Return SHA-256 hex digest of a file."""
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()


def sha256_string(s: str) -> str:
    return hashlib.sha256(s.encode()).hexdigest()


def decode_submission_hash_from_state(raw) -> str:
    """On-chain `submission_hash` is an ABI string (64-char hex), not a 32-byte address."""
    if isinstance(raw, bytes):
        return raw.decode("utf-8", errors="replace")
    return str(raw) if raw else ""


def verify_test_suite(local_test_path: str, frozen_hash: str) -> bool:
    """Verify test file matches the hash frozen at bounty creation."""
    actual = sha256_file(local_test_path)
    return actual == frozen_hash


# ── Piston API Runner ────────────────────────────────────────────────────────

LANGUAGE_MAP = {
    ".py": "python",
    ".js": "javascript",
    ".ts": "typescript",
    ".rs": "rust",
    ".go": "go",
    ".java": "java",
    ".cpp": "c++",
    ".c": "c",
}


def detect_language(file_path: str) -> str:
    ext = Path(file_path).suffix
    return LANGUAGE_MAP.get(ext, "python")


def run_code_piston(language: str, code: str, test_code: str) -> dict:
    """Run test suite against submitted code using Piston API."""
    combined = code + "\n\n" + test_code

    ext_map = {v: k for k, v in LANGUAGE_MAP.items()}
    ext = ext_map.get(language, ".py")

    payload = {
        "language": language,
        "version": "*",
        "files": [{"name": f"main{ext}", "content": combined}],
        "stdin": "",
        "args": [],
        "compile_timeout": 10000,
        "run_timeout": 5000,
    }

    try:
        resp = requests.post(f"{PISTON_API_URL}/execute", json=payload, timeout=30)
        resp.raise_for_status()
        result = resp.json()

        run = result.get("run", {})
        return {
            "success": run.get("code", 1) == 0,
            "output": run.get("stdout", ""),
            "stderr": run.get("stderr", ""),
            "exit_code": run.get("code", -1),
        }
    except requests.RequestException as e:
        return {
            "success": False,
            "output": "",
            "stderr": f"Piston API error: {e}",
            "exit_code": -1,
        }


# ── LocalNet Helpers ──────────────────────────────────────────────────────────

def get_algod():
    return algod.AlgodClient(ALGOD_TOKEN, ALGOD_ADDRESS)


def get_oracle_account():
    """Get the oracle account from KMD (uses account[2] as oracle/arbitrator)."""
    kmd_client = kmd.KMDClient(KMD_TOKEN, KMD_ADDRESS)
    wallets = kmd_client.list_wallets()
    default_wallet = next(
        (w for w in wallets if w["name"] == "unencrypted-default-wallet"), None
    )
    if not default_wallet:
        raise RuntimeError("LocalNet wallet not found")

    handle = kmd_client.init_wallet_handle(default_wallet["id"], "")
    addresses = kmd_client.list_keys(handle)

    # Use third account as oracle
    if len(addresses) < 3:
        raise RuntimeError("Need at least 3 LocalNet accounts")

    addr = addresses[2]
    pk = kmd_client.export_key(handle, "", addr)
    kmd_client.release_wallet_handle(handle)

    return {"address": addr, "private_key": pk}


# ── Oracle Logic ──────────────────────────────────────────────────────────────

class OracleRunner:
    """Oracle that evaluates code submissions and submits verdicts on-chain."""

    def __init__(self, app_id: int):
        self.app_id = app_id
        self.algod = get_algod()
        self.oracle_account = get_oracle_account()
        self.contract = load_contract()
        print(f"[Oracle] Initialized for App ID: {app_id}")
        print(f"[Oracle] Oracle address: {self.oracle_account['address'][:20]}...")

    def evaluate(
        self,
        submitted_code: str,
        test_code: str,
        frozen_test_hash: str,
        expected_submission_hash: str | None = None,
        language: str = "python",
    ) -> dict:
        """Full evaluation pipeline: verify hashes → run tests → return verdict."""
        print(f"[Oracle] Starting evaluation for app {self.app_id}")
        observed_submission_hash = sha256_string(submitted_code)

        if expected_submission_hash and observed_submission_hash != expected_submission_hash:
            reason = "Submitted artifact hash mismatch — possible evidence drift"
            return {
                "verdict": "FAIL",
                "reason": reason,
                "submission_hash_ok": False,
                "observed_submission_hash": observed_submission_hash,
                "oracle_output_hash": sha256_string(""),
                "verdict_reason_hash": sha256_string(reason),
            }

        # Step 1: Verify test suite hash
        actual_test_hash = sha256_string(test_code)
        if actual_test_hash != frozen_test_hash:
            reason = "Test suite hash mismatch — possible tampering"
            return {
                "verdict": "FAIL",
                "reason": reason,
                "test_hash_ok": False,
                "submission_hash_ok": expected_submission_hash is None or observed_submission_hash == expected_submission_hash,
                "observed_submission_hash": observed_submission_hash,
                "oracle_output_hash": sha256_string(""),
                "verdict_reason_hash": sha256_string(reason),
            }
        print(f"[Oracle] ✅ Test suite hash verified: {actual_test_hash[:16]}...")

        # Step 2: Verify non-empty submission
        if not submitted_code.strip():
            reason = "Empty submission"
            return {
                "verdict": "FAIL",
                "reason": reason,
                "test_hash_ok": True,
                "submission_hash_ok": expected_submission_hash is None or observed_submission_hash == expected_submission_hash,
                "observed_submission_hash": observed_submission_hash,
                "oracle_output_hash": sha256_string(""),
                "verdict_reason_hash": sha256_string(reason),
            }

        # Step 3: Run tests via Piston
        print(f"[Oracle] Running {language} tests via Piston API...")
        result = run_code_piston(language, submitted_code, test_code)

        verdict = "PASS" if result["success"] else "FAIL"
        print(f"[Oracle] Test result: {verdict}")
        if result["output"]:
            print(f"[Oracle] stdout: {result['output'][:200]}")
        if result["stderr"]:
            print(f"[Oracle] stderr: {result['stderr'][:200]}")
        oracle_output = "\n".join(
            part for part in [result.get("output", ""), result.get("stderr", "")] if part
        )
        reason = result["output"] if result["success"] else result["stderr"]

        return {
            "verdict": verdict,
            "reason": reason,
            "exit_code": result["exit_code"],
            "test_hash_ok": True,
            "submission_hash_ok": expected_submission_hash is None or observed_submission_hash == expected_submission_hash,
            "observed_submission_hash": observed_submission_hash,
            "oracle_output_hash": sha256_string(oracle_output),
            "verdict_reason_hash": sha256_string(reason),
        }

    def submit_verdict(
        self,
        verdict: str,
        observed_submission_hash: str,
        oracle_output_hash: str,
        verdict_reason_hash: str,
    ):
        """Submit oracle_verdict to the smart contract on LocalNet."""
        print(f"[Oracle] Submitting verdict '{verdict}' to app {self.app_id}...")

        atc = AtomicTransactionComposer()
        method = self.contract.get_method_by_name("oracle_verdict")
        signer = AccountTransactionSigner(self.oracle_account["private_key"])
        params = self.algod.suggested_params()
        params.fee = 2000
        params.flat_fee = True
        state = decode_app_state(self.algod, self.app_id)
        creator_addr = state.get("creator", b"")
        contributor_addr = state.get("contributor", b"")

        if isinstance(creator_addr, bytes) and len(creator_addr) == 32:
            creator_addr = encoding.encode_address(creator_addr)
        elif isinstance(creator_addr, bytes):
            creator_addr = creator_addr.decode("utf-8", errors="replace")
        if isinstance(contributor_addr, bytes) and len(contributor_addr) == 32:
            contributor_addr = encoding.encode_address(contributor_addr)
        elif isinstance(contributor_addr, bytes):
            contributor_addr = contributor_addr.decode("utf-8", errors="replace")

        atc.add_method_call(
            app_id=self.app_id,
            method=method,
            sender=self.oracle_account["address"],
            sp=params,
            signer=signer,
            method_args=[
                verdict,
                observed_submission_hash,
                oracle_output_hash,
                verdict_reason_hash,
                creator_addr,
                contributor_addr,
            ],
            accounts=[creator_addr, contributor_addr],
            boxes=[score_box_ref(self.app_id, contributor_addr)],
        )

        result = atc.execute(self.algod, 4)
        tx_id = result.tx_ids[0]
        print(f"[Oracle] ✅ Verdict submitted! TxID: {tx_id}")
        return tx_id

    def poll_and_evaluate(self):
        """
        Poll mode: watch contract state, auto-evaluate when DISPUTED + auto.
        Runs in a loop until Ctrl+C.
        """
        print(f"[Oracle] 🔄 Starting poll mode (every {POLL_INTERVAL}s)...")
        print(f"[Oracle] Watching App ID: {self.app_id}")
        print(f"[Oracle] Press Ctrl+C to stop\n")

        last_status = -1

        while True:
            try:
                state = decode_app_state(self.algod, self.app_id)
                status = state.get("status", 0)
                arb_type = state.get("arbitrator_type", b"auto")

                if isinstance(arb_type, bytes):
                    arb_type = arb_type.decode("utf-8", errors="replace")

                if status != last_status:
                    status_labels = {
                        0: "OPEN", 1: "ACCEPTED", 2: "SUBMITTED", 3: "APPROVED",
                        4: "REJECTED", 5: "DISPUTED", 6: "RESOLVED_WORKER",
                        7: "RESOLVED_CREATOR", 8: "OPTED_OUT",
                    }
                    print(f"[Oracle] Status changed: {status_labels.get(status, '?')} ({status})")
                    last_status = status

                # Auto-evaluate when disputed + auto arbitrator
                if status == 5 and arb_type == "auto":
                    print(f"[Oracle] 🎯 DISPUTED state detected with auto arbitrator!")
                    print(f"[Oracle] In production, would fetch IPFS content and run tests.")
                    print(f"[Oracle] For demo: submitting a recorded PASS verdict against the stored evidence hash...")

                    # In a real implementation, we'd:
                    # 1. Fetch work_ipfs_hash content from IPFS
                    # 2. Fetch test suite from IPFS
                    # 3. Verify test suite hash
                    # 4. Run tests via Piston
                    # For demo, we just submit PASS
                    try:
                        submission_hash = decode_submission_hash_from_state(
                            state.get("submission_hash", b"")
                        )
                        demo_reason = "Demo oracle poll mode: no off-chain fetch configured, using stored submission hash."
                        self.submit_verdict(
                            "PASS",
                            submission_hash,
                            sha256_string(demo_reason),
                            sha256_string(demo_reason),
                        )
                        print(f"[Oracle] ✅ Auto-evaluation complete!")
                    except Exception as e:
                        print(f"[Oracle] ❌ Verdict submission failed: {e}")

                time.sleep(POLL_INTERVAL)

            except KeyboardInterrupt:
                print(f"\n[Oracle] 🛑 Poll mode stopped.")
                break
            except Exception as e:
                print(f"[Oracle] ⚠️ Error: {e}")
                time.sleep(POLL_INTERVAL)


# ── CLI Entry Point ───────────────────────────────────────────────────────────

def main():
    if len(sys.argv) < 2:
        print("Bounty Escrow Oracle — LocalNet Edition")
        print()
        print("Usage:")
        print("  Manual evaluation:")
        print("    python oracle_runner.py <code_file> <test_file> <frozen_hash>")
        print()
        print("  Auto-poll mode (watches contract, auto-evaluates disputes):")
        print("    python oracle_runner.py --poll <app_id>")
        print()
        print("  Submit verdict directly:")
        print("    python oracle_runner.py --verdict <app_id> <PASS|FAIL>")
        sys.exit(0)

    if sys.argv[1] == "--poll":
        if len(sys.argv) < 3:
            print("Usage: python oracle_runner.py --poll <app_id>")
            sys.exit(1)
        app_id = int(sys.argv[2])
        runner = OracleRunner(app_id)
        runner.poll_and_evaluate()

    elif sys.argv[1] == "--verdict":
        if len(sys.argv) < 4:
            print("Usage: python oracle_runner.py --verdict <app_id> <PASS|FAIL>")
            sys.exit(1)
        app_id = int(sys.argv[2])
        verdict = sys.argv[3].upper()
        if verdict not in ("PASS", "FAIL"):
            print("Verdict must be PASS or FAIL")
            sys.exit(1)
        runner = OracleRunner(app_id)
        state = decode_app_state(runner.algod, app_id)
        submission_hash = decode_submission_hash_from_state(state.get("submission_hash", b""))
        reason = f"Manual oracle verdict submitted from CLI: {verdict}"
        runner.submit_verdict(
            verdict,
            submission_hash,
            sha256_string(reason),
            sha256_string(reason),
        )

    else:
        # Manual evaluation mode
        if len(sys.argv) < 4:
            print("Usage: python oracle_runner.py <code_file> <test_file> <frozen_hash>")
            sys.exit(1)

        code_path = sys.argv[1]
        test_path = sys.argv[2]
        frozen_hash = sys.argv[3]

        with open(code_path) as f:
            submitted_code = f.read()
        with open(test_path) as f:
            test_code = f.read()

        language = detect_language(code_path)

        runner = OracleRunner(app_id=0)
        result = runner.evaluate(submitted_code, test_code, frozen_hash, language=language)
        print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
